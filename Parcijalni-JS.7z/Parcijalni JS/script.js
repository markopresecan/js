"use-strict";

const searchInput = document.getElementById('searchInput');
const loader = document.getElementById('loader');
const resultContainer = document.getElementById('resultContainer');

let timeoutId;

searchInput.addEventListener('input', function() {
  clearTimeout(timeoutId);
  const searchTerm = this.value;
  if (searchTerm.trim() !== '') {
    loader.style.display = 'block';
    resultContainer.innerHTML = '';
    timeoutId = setTimeout(() => {
      searchiTunes(searchTerm)
        .then(displayResults)
        .catch(displayError)
        .finally(() => {
          loader.style.display = 'none';
        });
    }, 500);
  } else {
    resultContainer.innerHTML = '';
  }
});

function searchiTunes(term) {
  const url = `https://itunes.apple.com/search?term=${encodeURIComponent(term)}&entity=song`;
  return fetch(url)
    .then(response => response.json())
    .then(data => data.results);
}

function displayResults(results) {
  if (results.length > 0) {
    const table = document.createElement('table');
    const headerRow = document.createElement('tr');
    const header1 = document.createElement('th');
    header1.textContent = 'Pjesma';
    const header2 = document.createElement('th');
    header2.textContent = 'Izvođač';
    headerRow.appendChild(header1);
    headerRow.appendChild(header2);
    table.appendChild(headerRow);

    for (const result of results) {
      const row = document.createElement('tr');
      const cell1 = document.createElement('td');
      cell1.textContent = result.trackName;
      const cell2 = document.createElement('td');
      cell2.textContent = result.artistName;
      row.appendChild(cell1);
      row.appendChild(cell2);
      table.appendChild(row);
    }

    resultContainer.appendChild(table);
  } else {
    const message = document.createElement('p');
    message.textContent = 'Nema rezultata za traženi pojam.';
    resultContainer.appendChild(message);
  }
}

function displayError(error) {
  console.error(error);
  const message = document.createElement('p');
  message.textContent = 'Došlo je do pogreške prilikom dohvaćanja podataka.';
  resultContainer.appendChild(message);
}
